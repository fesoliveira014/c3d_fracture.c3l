# Reproducing the independent collision audit

This is ignored acceptance evidence, not production Python or a library dependency.
Use Python 3.11 or newer; every dependency is in the standard library.

From this directory:

```text
python -m unittest -v test_collision_oracle
python collision_oracle.py collision-pruned-o3.json --output reproduced-pruned.json --jobs 4
```

The second command must exit 0 and report 96 PASS cases. It independently measures
coverage, overlap and exterior error, then checks raw source-position retention.
The JSON uses exact binary32 input bits and exact rational output numerators and
denominators. `seconds` fields are runtime diagnostics and will differ between
runs; they are not kernel performance measurements. Compare all other result
fields exactly. Full method and assumptions are in collision-oracle-method.md.

The reproduced 96-case inventory has four source shapes, 12 rotations and hull limits
128/4. This evidence predates the separate authored coplanar-subdivision fix; its
extra face-center/edge-point cases must be added before final collision acceptance.
Native cooking and cavity/notch probes are separate recorded acceptance checks.

`baseline/` preserves the earlier immutable export and exact v1 oracle report.
Its 96 geometric checks passed, but 15 cases at limit 4 omitted 28 authored source positions
and 36 nonconvex cases at limit 4 failed native cooking. Those baseline results are not
claimed as accepted collision output. The corrected export reduces 17,217 hulls to
9,877 and 75,330 point entries to 41,810, and retains all 1,440 source-position occurrences
in the 96-case inventory.

SHA256SUMS records every file in this evidence directory except itself.
