# Independent collision volume oracle

The acceptance script `collision_oracle.py` uses Python's standard-library
`Fraction` arithmetic over the exported binary32 bit patterns. It does not call
the C3 clipping, predicates, source classification, volume routines or certificates.
It is ignored acceptance tooling, not a library runtime dependency.

For each oriented source triangle `(a,b,c)`, form the tetrahedral cone from the
origin and assign the sign of `det(a,b,c)`. A closed outward surface is a signed
indicator sum of these cones away from its boundaries. Reversed cavity shells
subtract material, and islands or disconnected outer shells add material. The
origin need not lie inside the source.

For a convex published hull `H`, independently clip it by each cone's four exact
supporting half-spaces. Each clip retains ordered face polygons and creates the
cap with an exact planar convex hull. The resulting oriented boundary determinant
sum gives its rational volume. Summing signed cone-intersection volumes gives
`I_i = volume(H_i intersect S)` exactly, including cavities and concavity.

Also compute exact pairwise hull-intersection volumes with an AABB rejection
before clipping. Let:

```text
V = volume(S)
I = sum_i volume(H_i intersect S)
P = sum_{i<j} volume(H_i intersect H_j)
D = sum_i volume(H_i) - V
```

At a point covered by `n` hulls, `max(n-1,0) <= n*(n-1)/2`. Therefore conservative
independent bounds are:

```text
missing volume U <= max(0, V - I + P)
overlap multiplicity O <= P
exterior union volume X <= sum_i [volume(H_i) - volume(H_i intersect S)]
```

These are upper bounds. In particular `P` is not called the exact overlap, and
`V-I+P` is not called the exact missing volume. Independent lower bounds are
`max(0,V-I)` for missing volume, the largest individual exterior volume for
exterior union volume, and the largest pair intersection for overlap multiplicity.

The script independently evaluates the documented source displacement allowance
`B` from the source triangles and the cube expansion allowance
`E = sum_i [epsilon*Q_i/2 + 4*epsilon^2*W_i + 8*epsilon^3]` from the actual published
hulls. Here `Q_i` is the sum of L1 triangle cross products and `W_i` is the sum of
the three hull widths. It requires `D <= B`, `U <= E`, `X <= B+E` and `O <= B+E`.

PASS means every independent upper bound meets its corresponding allowance.
FAIL means `D > B` or an independent lower bound proves an allowance was exceeded.
INCONCLUSIVE means the available upper bounds are too loose to establish the
allowance, without a proven violation. The latter is not a passing acceptance
result. Invalid exported geometry is ERROR. Any nonempty exporter `failures`
array also prevents a successful exit.

The source-retention check compares raw uint32 XYZ tuples, not numerical equality.
Every distinct used source position must occur in the union of the published hull
point arrays. This preserves signed-zero distinctions and checks the final output,
including the tetrahedral fallback. Reports identify missing source vertex indices
and record total/unique source and generated point counts. An omitted source point
is a separate FAIL even when its geometric volume bounds pass.

The oracle checks closed edge incidence of the source and every hull, positive
signed volume, convex hull facet support and containment of all exported hull
points, including points unused by the hull triangulation. The source is assumed
to be the already-validated non-self-intersecting input solid; this oracle is not
an independent general mesh self-intersection validator. It measures output
coverage directly and does not infer it from the C3 chunk partition or its bounds.

`test_collision_oracle.py` covers exact bit decoding, 72 seeded rational box
intersections under shear/reflection, rational tetrahedron cuts, boundary contacts,
subnormal/extreme dyadics, shifted cone origins with signed cancellation, hollow,
concave, disconnected and nested-island solids. It also checks known independent
gap/overlap/exterior errors, loose-bound classification, and the cube expansion
formula against an explicitly constructed oblique Minkowski hull.

Run the analytic checks with `python -m unittest -v test_collision_oracle` from
this directory. Run exported cases with
`python collision_oracle.py export.json --output oracle-report.json`.
`--jobs 4` evaluates independent cases in four worker processes while preserving
report order. Exact arithmetic is unchanged. Decimal serialization permits large
integers because these rational sums can exceed Python's default 4,300-digit
conversion limit.
The report preserves every rational numerator and denominator; decimal values
are display approximations only. Final fixture acceptance additionally requires
the expected complete case inventory and no reconstruction failures.
