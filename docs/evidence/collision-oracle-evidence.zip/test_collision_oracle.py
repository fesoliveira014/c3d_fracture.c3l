"""Analytic checks of the independent exact collision-volume oracle."""

from fractions import Fraction as F
from itertools import combinations, product
import random
import unittest

import collision_oracle as oracle


def box(lower, upper):
    vertices = tuple(oracle.point((x, y, z)) for z in (lower[2], upper[2])
                     for y in (lower[1], upper[1]) for x in (lower[0], upper[0]))
    indices = ((0, 4, 6, 2), (1, 3, 7, 5), (0, 1, 5, 4),
               (2, 6, 7, 3), (0, 2, 3, 1), (4, 5, 7, 6))
    return oracle.Polyhedron(tuple(tuple(vertices[index] for index in face) for face in indices))


def triangles(polyhedron, reverse=False):
    result = []
    for face in polyhedron.faces:
        for index in range(1, len(face) - 1):
            triangle = (face[0], face[index], face[index + 1])
            result.append(tuple(reversed(triangle)) if reverse else triangle)
    return tuple(result)


def transform(polyhedron, matrix, translation=oracle.ZERO):
    def apply(vertex):
        return oracle.add(tuple(oracle.dot(row, vertex) for row in matrix), translation)
    sign = oracle.determinant(*matrix)
    return oracle.Polyhedron(tuple(tuple(apply(vertex) for vertex in (face if sign > 0 else reversed(face)))
                                   for face in polyhedron.faces))


def l_prism():
    footprint = ((0, 0), (2, 0), (2, 1), (1, 1), (1, 2), (0, 2))
    vertices = tuple(oracle.point((x, y, z)) for z in (0, 1) for x, y in footprint)
    faces = []
    for index in range(1, 5):
        faces.append((vertices[0], vertices[index + 1], vertices[index]))
        faces.append((vertices[6], vertices[index + 6], vertices[index + 7]))
    for index in range(6):
        following = (index + 1) % 6
        faces.append((vertices[index], vertices[following], vertices[following + 6], vertices[index + 6]))
    return oracle.Source(triangles(oracle.Polyhedron(tuple(faces))))


def supporting_hull(vertices):
    vertices = tuple(sorted(set(vertices)))
    planes = set()
    for face in combinations(vertices, 3):
        if not oracle.clean_face(face):
            continue
        plane = oracle.face_plane(face)
        distances = tuple(oracle.side(plane, vertex) for vertex in vertices)
        if min(distances) < 0 < max(distances):
            continue
        if min(distances) >= 0:
            plane = tuple(-coefficient for coefficient in plane)
        planes.add(plane)
    return oracle.Polyhedron(tuple(oracle.planar_hull(
        (vertex for vertex in vertices if oracle.side(plane, vertex) == 0), plane,
    ) for plane in sorted(planes)))


class ExactResultEncoding(unittest.TestCase):
    def test_large_rational_results_preserve_decimal_numerators(self):
        value = F(10**5000 + 1, 10**5000 + 3)
        encoded = oracle.encode_result(value)
        self.assertEqual(F(int(encoded['numerator']), int(encoded['denominator'])), value)

    def test_source_retention_compares_used_position_bits_without_zero_canonicalization(self):
        case = {'source': {'positions_bits': [[0, 0, 0], [0x80000000, 0, 0],
                                              [0x3F800001, 0, 0], [0x3F800002, 0, 0]],
                           'indices': [0, 1, 2]},
                'hulls': [{'positions_bits': [[0, 0, 0], [0x3F800001, 0, 0], [0x3F800003, 0, 0]]}]}
        result = oracle.source_vertex_inventory(case)
        self.assertEqual(result['source_unique_positions'], 3)
        self.assertEqual(result['generated_unique_positions'], 1)
        self.assertEqual(result['missing_source_positions'],
                         [{'position_bits': [0x80000000, 0, 0], 'source_indices': [1]}])
        case['hulls'][0]['positions_bits'].append([0x80000000, 0, 0])
        self.assertEqual(oracle.source_vertex_inventory(case)['missing_source_positions'], [])


class ExactConvexClipping(unittest.TestCase):
    def test_binary32_decode_is_exact(self):
        self.assertEqual(oracle.float_bits(0), 0)
        self.assertEqual(oracle.float_bits(0x80000000), 0)
        self.assertEqual(oracle.float_bits(1), F(1, 2**149))
        self.assertEqual(oracle.float_bits(0x00800000), F(1, 2**126))
        self.assertEqual(oracle.float_bits(0x3F800001), 1 + F(1, 2**23))
        self.assertEqual(oracle.float_bits(0xBF000000), F(-1, 2))
        self.assertEqual(oracle.float_bits(0x7F7FFFFF), F((2**24 - 1) * 2**104))
        for bits in (0x7F800000, 0x7FC00001, 0xFF800000, -1, 2**32):
            with self.assertRaises(ValueError):
                oracle.float_bits(bits)

    def test_seeded_boxes_match_product_of_interval_intersections(self):
        random_source = random.Random(8407)
        transforms = (
            ((F(1), F(0), F(0)), (F(0), F(1), F(0)), (F(0), F(0), F(1))),
            ((F(1), F(2), F(-1)), (F(0), F(1), F(3)), (F(0), F(0), F(1))),
            ((F(-2), F(0), F(0)), (F(0), F(3), F(0)), (F(0), F(0), F(1, 2))),
        )
        for case in range(72):
            lower_a = tuple(F(random_source.randrange(-9, 5), 3) for _ in range(3))
            lower_b = tuple(F(random_source.randrange(-9, 5), 3) for _ in range(3))
            upper_a = tuple(value + F(random_source.randrange(1, 10), 3) for value in lower_a)
            upper_b = tuple(value + F(random_source.randrange(1, 10), 3) for value in lower_b)
            expected = F(1)
            for axis in range(3):
                expected *= max(F(0), min(upper_a[axis], upper_b[axis]) - max(lower_a[axis], lower_b[axis]))
            matrix = transforms[case % len(transforms)]
            translation = oracle.point((F(13, 7), F(-9, 5), F(2, 11)))
            first = transform(box(lower_a, upper_a), matrix, translation)
            second = transform(box(lower_b, upper_b), matrix, translation)
            expected *= abs(oracle.determinant(*matrix))
            first.check_convex()
            second.check_convex()
            self.assertEqual(oracle.intersection(first, second).volume, expected)
            self.assertEqual(oracle.intersection(second, first).volume, expected)

    def test_tetrahedron_rational_halfspaces_have_analytic_volume(self):
        tetrahedron = oracle.tetrahedron((oracle.ZERO, oracle.point((1, 0, 0)),
                                         oracle.point((0, 1, 0)), oracle.point((0, 0, 1))))
        tetrahedron.check_convex()
        self.assertEqual(tetrahedron.volume, F(1, 6))
        for denominator in (2, 3, 7, 17):
            for numerator in range(denominator + 1):
                fraction = F(numerator, denominator)
                clipped = oracle.clip(tetrahedron, (-denominator, 0, 0, numerator))
                self.assertEqual(clipped.volume, (1 - fraction)**3 / 6)
                scaled = oracle.clip(tetrahedron, (denominator, denominator, denominator, -numerator))
                self.assertEqual(scaled.volume, fraction**3 / 6)

    def test_coplanar_faces_edges_vertices_and_extreme_dyadics(self):
        unit = box((0, 0, 0), (1, 1, 1))
        self.assertEqual(oracle.clip(unit, (1, 0, 0, -1)).volume, 1)
        for lower, upper in (((1, 0, 0), (2, 1, 1)), ((1, 1, 0), (2, 2, 1)),
                             ((1, 1, 1), (2, 2, 2))):
            self.assertEqual(oracle.intersection(unit, box(lower, upper)).volume, 0)
        for exponent in (-149, -126, 64, 104):
            width = F(2**exponent) if exponent >= 0 else F(1, 2**-exponent)
            thin = box((0, 0, 0), (width, 1, 1))
            sliced = oracle.clip(thin, (-1, 0, 0, width / 2))
            self.assertEqual(sliced.volume, width / 2)


class SignedConeIntegration(unittest.TestCase):
    def test_convex_source_intersections_ignore_cone_origin(self):
        source_box = box((-1, -1, -1), (1, 1, 1))
        query = box((-2, F(-1, 2), F(-1, 2)), (0, F(1, 2), F(1, 2)))
        for origin in (oracle.ZERO, oracle.point((13, -7, 5)), oracle.point((F(1, 7), F(9, 5), -4))):
            source = oracle.Source(triangles(source_box), origin)
            self.assertEqual(source.volume, 8)
            self.assertEqual(source.intersect_volume(query), 1)
            self.assertEqual(sum(sign * cone.volume for sign, cone in source.cones), 8)

    def test_translated_source_has_signed_cones_with_exact_cancellation(self):
        source_box = box((5, 3, -4), (7, 5, -2))
        query = box((4, 2, -5), (6, 6, -1))
        source = oracle.Source(triangles(source_box))
        self.assertTrue(any(sign < 0 for sign, _ in source.cones))
        self.assertTrue(any(sign > 0 for sign, _ in source.cones))
        self.assertEqual(source.intersect_volume(query), 4)

    def test_hollow_source_retains_the_cavity(self):
        outer = box((-2, -2, -2), (2, 2, 2))
        cavity = box((-1, -1, -1), (1, 1, 1))
        source = oracle.Source(triangles(outer) + triangles(cavity, reverse=True))
        oracle.check_closed_surface(source.triangles)
        self.assertEqual(source.volume, 56)
        self.assertEqual(source.intersect_volume(box((F(-1, 2),) * 3, (F(1, 2),) * 3)), 0)
        self.assertEqual(source.intersect_volume(box((-2, -2, -2), (0, 2, 2))), 28)
        self.assertEqual(source.intersect_volume(outer), 56)

    def test_concave_notch_and_disconnected_material_are_exact(self):
        source = l_prism()
        oracle.check_closed_surface(source.triangles)
        self.assertEqual(source.volume, 3)
        self.assertEqual(source.intersect_volume(box((F(1, 2), F(1, 2), 0), (F(3, 2), F(3, 2), 1))), F(3, 4))
        self.assertEqual(source.intersect_volume(box((1, 1, 0), (2, 2, 1))), 0)
        first = box((-3, -1, -1), (-1, 1, 1))
        second = box((1, -1, -1), (3, 1, 1))
        disconnected = oracle.Source(triangles(first) + triangles(second))
        self.assertEqual(disconnected.volume, 16)
        self.assertEqual(disconnected.intersect_volume(box((-2, -2, -2), (2, 2, 2))), 8)

    def test_nested_island_adds_material_inside_a_cavity(self):
        outer = box((-3, -3, -3), (3, 3, 3))
        cavity = box((-2, -2, -2), (2, 2, 2))
        island = box((-1, -1, -1), (1, 1, 1))
        source = oracle.Source(triangles(outer) + triangles(cavity, True) + triangles(island))
        self.assertEqual(source.volume, 160)
        self.assertEqual(source.intersect_volume(outer), 160)
        self.assertEqual(source.intersect_volume(cavity), 8)
        self.assertEqual(source.intersect_volume(island), 8)


class IndependentCoverageBounds(unittest.TestCase):
    def setUp(self):
        self.unit = box((0, 0, 0), (1, 1, 1))
        self.source = oracle.Source(triangles(self.unit))

    def test_exact_partition_has_zero_error(self):
        hulls = (box((0, 0, 0), (F(1, 2), 1, 1)), box((F(1, 2), 0, 0), (1, 1, 1)))
        result = oracle.audit(self.source, hulls, F(1, 1000))
        self.assertEqual(result['status'], 'PASS')
        for key in ('missing_upper', 'overlap_upper', 'exterior_upper', 'signed_volume_difference'):
            self.assertEqual(result[key], 0)

    def test_gap_overlap_and_exterior_growth_are_distinct(self):
        gap = (box((0, 0, 0), (F(2, 5), 1, 1)), box((F(3, 5), 0, 0), (1, 1, 1)))
        result = oracle.audit(self.source, gap, F(1, 1000))
        self.assertEqual(result['missing_lower'], F(1, 5))
        self.assertEqual(result['missing_upper'], F(1, 5))
        self.assertEqual(result['overlap_upper'], 0)
        self.assertEqual(result['exterior_upper'], 0)
        self.assertEqual(result['status'], 'FAIL')

        overlap = (box((0, 0, 0), (F(3, 5), 1, 1)), box((F(2, 5), 0, 0), (1, 1, 1)))
        result = oracle.audit(self.source, overlap, F(1, 1000))
        self.assertEqual(result['missing_upper'], 0)
        self.assertEqual(result['overlap_upper'], F(1, 5))
        self.assertEqual(result['exterior_upper'], 0)
        self.assertEqual(result['status'], 'FAIL')

        exterior = (box((F(-1, 10), 0, 0), (F(11, 10), 1, 1)),)
        result = oracle.audit(self.source, exterior, F(1, 1000))
        self.assertEqual(result['missing_upper'], 0)
        self.assertEqual(result['overlap_upper'], 0)
        self.assertEqual(result['exterior_lower'], F(1, 5))
        self.assertEqual(result['exterior_upper'], F(1, 5))
        self.assertEqual(result['status'], 'FAIL')

    def test_three_hulls_report_pair_sum_as_a_bound_not_true_overlap(self):
        result = oracle.audit(self.source, (self.unit, self.unit, self.unit), F(1, 1000))
        self.assertEqual(result['signed_volume_difference'], 2)
        self.assertEqual(result['overlap_upper'], 3)
        self.assertEqual(result['missing_upper'], 1)
        self.assertEqual(result['exterior_upper'], 0)

    def test_loose_upper_bounds_are_inconclusive_not_false_failures(self):
        small = box((0, 0, 0), (F(1, 20),) * 3)
        result = oracle.audit(self.source, (self.unit,) + (small,) * 20, F(1, 1000))
        self.assertEqual(result['status'], 'INCONCLUSIVE')
        self.assertEqual(result['violations'], [])
        self.assertLess(result['signed_volume_difference'], result['source_bound_B'])
        self.assertGreater(result['overlap_upper'], result['exterior_overlap_bound_B_plus_E'])

    def test_cube_growth_formula_matches_exact_expanded_boxes(self):
        for epsilon in (F(1, 1000), F(1, 7), F(3, 2)):
            hull = box((F(-1, 3), 2, -5), (F(7, 3), 4, -2))
            lower = tuple(pair[0] - epsilon for pair in hull.bounds)
            upper = tuple(pair[1] + epsilon for pair in hull.bounds)
            self.assertEqual(oracle.hull_cube_excess(hull, epsilon), box(lower, upper).volume - hull.volume)

    def test_cube_growth_formula_matches_constructed_oblique_minkowski_hull(self):
        tetrahedron = oracle.tetrahedron((oracle.ZERO, oracle.point((1, 0, 0)),
                                         oracle.point((1, 2, 0)), oracle.point((-1, 1, 3))))
        epsilon = F(1, 7)
        summed = tuple(oracle.add(vertex, oracle.point(offset)) for vertex in tetrahedron.vertices
                       for offset in product((-epsilon, epsilon), repeat=3))
        enlarged = supporting_hull(summed)
        enlarged.check_convex()
        self.assertEqual(oracle.hull_cube_excess(tetrahedron, epsilon), enlarged.volume - tetrahedron.volume)

    def test_reflected_hull_and_open_source_are_rejected(self):
        wrong = oracle.Polyhedron(tuple(tuple(reversed(face)) for face in self.unit.faces))
        with self.assertRaises(ValueError):
            oracle.audit(self.source, (wrong,), F(1, 1000))
        with self.assertRaises(ValueError):
            oracle.audit(oracle.Source(self.source.triangles[:-1]), (self.unit,), F(1, 1000))
        outside_point = oracle.Polyhedron(self.unit.faces, (oracle.point((2, 0, 0)),))
        with self.assertRaises(ValueError):
            oracle.audit(self.source, (outside_point,), F(1, 1000))


if __name__ == '__main__':
    unittest.main(verbosity=2)
