"""Independent Fraction volume oracle for exported binary32 collision fixtures.

This is acceptance tooling in the ignored change directory, not library runtime.
The oracle clips convex polyhedra with rational half-spaces. It integrates a
possibly concave, disconnected or hollow source as signed tetrahedral cones.
Pairwise hull intersections yield conservative error upper bounds; they are not
reported as the exact union volume or exact overlap multiplicity.
"""

from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass
from fractions import Fraction as F
from functools import cached_property
from math import gcd, lcm
import json
from pathlib import Path
import sys
import time
from typing import Iterable

Point = tuple[F, F, F]
Face = tuple[Point, ...]
Plane = tuple[int, int, int, int]
ZERO: Point = (F(0), F(0), F(0))

# Exact sums can legitimately exceed Python's default decimal conversion limit.
sys.set_int_max_str_digits(0)


def add(a: Point, b: Point) -> Point:
    return tuple(x + y for x, y in zip(a, b))


def subtract(a: Point, b: Point) -> Point:
    return tuple(x - y for x, y in zip(a, b))


def scale(a: Point, multiplier: F) -> Point:
    return tuple(x * multiplier for x in a)


def dot(a, b) -> F:
    return sum((x * y for x, y in zip(a, b)), F(0))


def cross(a: Point, b: Point) -> Point:
    return (a[1] * b[2] - a[2] * b[1],
            a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0])


def determinant(a: Point, b: Point, c: Point) -> F:
    return dot(a, cross(b, c))


def point(values) -> Point:
    return tuple(F(value) for value in values)


def float_bits(bits: int) -> F:
    if not isinstance(bits, int) or not 0 <= bits <= 0xFFFFFFFF:
        raise ValueError("A binary32 coordinate must be a uint32 bit pattern")
    exponent = (bits >> 23) & 0xFF
    mantissa = bits & 0x7FFFFF
    if exponent == 0xFF:
        raise ValueError("Nonfinite binary32 coordinate")
    if exponent:
        mantissa += 1 << 23
        power = exponent - 150
    else:
        power = -149
    value = F(mantissa << power) if power >= 0 else F(mantissa, 1 << -power)
    return -value if bits >> 31 else value


def clean_face(vertices: Iterable[Point]) -> Face:
    result = []
    for vertex in vertices:
        if not result or vertex != result[-1]:
            result.append(vertex)
    if len(result) > 1 and result[0] == result[-1]:
        result.pop()
    if len(result) < 3:
        return ()
    first = subtract(result[1], result[0])
    if not any(cross(first, subtract(vertex, result[0])) != ZERO for vertex in result[2:]):
        return ()
    return tuple(result)


def face_plane(face: Face) -> Plane:
    normal = ZERO
    for index in range(1, len(face) - 1):
        normal = cross(subtract(face[index], face[0]), subtract(face[index + 1], face[0]))
        if normal != ZERO:
            break
    if normal == ZERO:
        raise ValueError("Degenerate face")
    values = (*normal, -dot(normal, face[0]))
    denominator = lcm(*(value.denominator for value in values))
    integers = [int(value * denominator) for value in values]
    common = gcd(*integers)
    return tuple(value // common for value in integers)


def side(plane: Plane, vertex: Point) -> F:
    return dot(plane[:3], vertex) + plane[3]


def planar_hull(vertices: Iterable[Point], plane: Plane) -> Face:
    dropped = max(range(3), key=lambda axis: abs(plane[axis]))
    axes = ((dropped + 1) % 3, (dropped + 2) % 3)
    ordered = sorted(set(vertices), key=lambda vertex: (vertex[axes[0]], vertex[axes[1]]))
    if len(ordered) < 3:
        return ()

    def turn(a, b, c):
        return ((b[axes[0]] - a[axes[0]]) * (c[axes[1]] - a[axes[1]])
                - (b[axes[1]] - a[axes[1]]) * (c[axes[0]] - a[axes[0]]))

    lower = []
    for vertex in ordered:
        while len(lower) >= 2 and turn(lower[-2], lower[-1], vertex) <= 0:
            lower.pop()
        lower.append(vertex)
    upper = []
    for vertex in reversed(ordered):
        while len(upper) >= 2 and turn(upper[-2], upper[-1], vertex) <= 0:
            upper.pop()
        upper.append(vertex)
    result = lower[:-1] + upper[:-1]
    if plane[dropped] < 0:
        result.reverse()
    return clean_face(result)


@dataclass(frozen=True)
class Polyhedron:
    faces: tuple[Face, ...]
    required_vertices: tuple[Point, ...] = ()

    @cached_property
    def vertices(self):
        return tuple(sorted({vertex for face in self.faces for vertex in face}))

    @cached_property
    def bounds(self):
        if not self.vertices:
            return None
        return tuple((min(vertex[axis] for vertex in self.vertices),
                      max(vertex[axis] for vertex in self.vertices)) for axis in range(3))

    @cached_property
    def planes(self):
        return tuple(sorted({face_plane(face) for face in self.faces}))

    @cached_property
    def volume(self):
        total = F(0)
        for face in self.faces:
            for index in range(1, len(face) - 1):
                total += determinant(face[0], face[index], face[index + 1])
        return total / 6

    def check_convex(self):
        if self.volume <= 0:
            raise ValueError("A hull must have positive outward volume")
        for plane in self.planes:
            if any(side(plane, vertex) > 0 for vertex in (*self.vertices, *self.required_vertices)):
                raise ValueError("A hull face does not support the convex point set")
        check_closed_surface(self.faces)


EMPTY = Polyhedron(())


def bounds_overlap(first: Polyhedron, second: Polyhedron) -> bool:
    if first.bounds is None or second.bounds is None:
        return False
    return all(max(a[0], b[0]) < min(a[1], b[1]) for a, b in zip(first.bounds, second.bounds))


def clip(polyhedron: Polyhedron, plane: Plane) -> Polyhedron:
    if not polyhedron.faces:
        return polyhedron
    distances = {vertex: side(plane, vertex) for vertex in polyhedron.vertices}
    low = min(distances.values())
    high = max(distances.values())
    if high <= 0:
        return polyhedron
    if low >= 0:
        return EMPTY

    faces = []
    cap = set()
    for face in polyhedron.faces:
        clipped = []
        for first, second in zip(face, face[1:] + face[:1]):
            start = distances[first]
            end = distances[second]
            if start <= 0:
                clipped.append(first)
                if start == 0:
                    cap.add(first)
            if (start < 0 < end) or (end < 0 < start):
                fraction = start / (start - end)
                intersection = add(first, scale(subtract(second, first), fraction))
                clipped.append(intersection)
                cap.add(intersection)
        retained = clean_face(clipped)
        if retained:
            faces.append(retained)
    closing = planar_hull(cap, plane)
    if closing:
        faces.append(closing)
    return Polyhedron(tuple(faces))


def intersection(first: Polyhedron, second: Polyhedron) -> Polyhedron:
    if not bounds_overlap(first, second):
        return EMPTY
    result = first
    for plane in second.planes:
        result = clip(result, plane)
        if not result.faces:
            break
    return result


def tetrahedron(vertices: tuple[Point, Point, Point, Point]) -> Polyhedron:
    faces = []
    for opposite in range(4):
        face = tuple(vertex for index, vertex in enumerate(vertices) if index != opposite)
        normal = cross(subtract(face[1], face[0]), subtract(face[2], face[0]))
        if dot(normal, subtract(vertices[opposite], face[0])) > 0:
            face = (face[0], face[2], face[1])
        faces.append(face)
    return Polyhedron(tuple(faces))


def check_closed_surface(faces: tuple[Face, ...]):
    edges = {}
    for face in faces:
        if not clean_face(face):
            raise ValueError("Degenerate source triangle")
        for first, second in zip(face, face[1:] + face[:1]):
            if first == second:
                raise ValueError("Zero-length surface edge")
            key = tuple(sorted((first, second)))
            forward, reverse = edges.get(key, (0, 0))
            if first < second:
                forward += 1
            else:
                reverse += 1
            edges[key] = (forward, reverse)
    if any(count != (1, 1) for count in edges.values()):
        raise ValueError("Surface edges are not paired with opposite winding")


@dataclass(frozen=True)
class Source:
    triangles: tuple[Face, ...]
    cone_origin: Point = ZERO

    @cached_property
    def volume(self):
        return sum((determinant(subtract(face[0], self.cone_origin),
                                subtract(face[1], self.cone_origin),
                                subtract(face[2], self.cone_origin))
                    for face in self.triangles), F(0)) / 6

    @cached_property
    def cones(self):
        result = []
        for face in self.triangles:
            signed = determinant(*(subtract(vertex, self.cone_origin) for vertex in face))
            if signed:
                result.append((1 if signed > 0 else -1,
                               tetrahedron((self.cone_origin, *face))))
        return tuple(result)

    def intersect_volume(self, hull: Polyhedron) -> F:
        total = sum((sign * intersection(hull, cone).volume for sign, cone in self.cones), F(0))
        if total < 0 or total > min(hull.volume, self.volume):
            raise ValueError("Signed-cone intersection is outside the volume bounds")
        return total


def triangle_metrics(triangles: tuple[Face, ...]):
    quadratic = F(0)
    linear = F(0)
    count = 0
    for face in triangles:
        for index in range(1, len(face) - 1):
            first = subtract(face[index], face[0])
            second = subtract(face[index + 1], face[0])
            quadratic += sum(abs(value) for value in cross(first, second))
            linear += sum(abs(value) for value in (*first, *second))
            count += 1
    return quadratic, linear, count


def source_displacement_bound(source: Source, epsilon: F) -> F:
    quadratic, linear, count = triangle_metrics(source.triangles)
    return epsilon * quadratic / 2 + epsilon**2 * linear / 2 + F(2, 3) * count * epsilon**3


def hull_cube_excess(hull: Polyhedron, epsilon: F) -> F:
    quadratic, _, _ = triangle_metrics(hull.faces)
    widths = sum((upper - lower for lower, upper in hull.bounds), F(0))
    return epsilon * quadratic / 2 + 4 * epsilon**2 * widths + 8 * epsilon**3


def audit(source: Source, hulls: tuple[Polyhedron, ...], epsilon: F):
    if epsilon <= 0:
        raise ValueError("The geometric resolution must be positive")
    check_closed_surface(source.triangles)
    if source.volume <= 0:
        raise ValueError("The source must have positive signed material volume")
    for hull in hulls:
        hull.check_convex()

    inside = tuple(source.intersect_volume(hull) for hull in hulls)
    pair_sum = F(0)
    pair_maximum = F(0)
    candidate_pairs = 0
    positive_pairs = 0
    for first in range(len(hulls)):
        for second in range(first + 1, len(hulls)):
            if not bounds_overlap(hulls[first], hulls[second]):
                continue
            candidate_pairs += 1
            overlap = intersection(hulls[first], hulls[second]).volume
            if overlap < 0:
                raise ValueError("Negative convex intersection volume")
            pair_sum += overlap
            pair_maximum = max(pair_maximum, overlap)
            positive_pairs += overlap > 0

    hull_volume = sum((hull.volume for hull in hulls), F(0))
    inside_sum = sum(inside, F(0))
    outside_each = tuple(hull.volume - value for hull, value in zip(hulls, inside))
    difference = hull_volume - source.volume
    missing_lower = max(F(0), source.volume - inside_sum)
    missing_upper = max(F(0), source.volume - inside_sum + pair_sum)
    exterior_lower = max(outside_each, default=F(0))
    exterior_upper = sum(outside_each, F(0))
    source_bound = source_displacement_bound(source, epsilon)
    missing_bound = sum((hull_cube_excess(hull, epsilon) for hull in hulls), F(0))
    combined_bound = source_bound + missing_bound

    violations = []
    if difference > source_bound:
        violations.append("signed_volume_excess")
    if missing_lower > missing_bound:
        violations.append("missing_volume")
    if exterior_lower > combined_bound:
        violations.append("exterior_volume")
    if pair_maximum > combined_bound:
        violations.append("overlap_multiplicity")

    upper_bounds_pass = (missing_upper <= missing_bound and exterior_upper <= combined_bound
                         and pair_sum <= combined_bound)
    status = "FAIL" if violations else "PASS" if upper_bounds_pass else "INCONCLUSIVE"
    return {
        "status": status,
        "violations": violations,
        "source_volume": source.volume,
        "hull_volume_sum": hull_volume,
        "hull_source_intersection_sum": inside_sum,
        "signed_volume_difference": difference,
        "pair_intersection_sum": pair_sum,
        "missing_lower": missing_lower,
        "missing_upper": missing_upper,
        "overlap_lower": pair_maximum,
        "overlap_upper": pair_sum,
        "exterior_lower": exterior_lower,
        "exterior_upper": exterior_upper,
        "source_bound_B": source_bound,
        "missing_bound_E": missing_bound,
        "exterior_overlap_bound_B_plus_E": combined_bound,
        "source_triangles": len(source.triangles),
        "hulls": len(hulls),
        "source_cones": len(source.cones),
        "candidate_hull_pairs": candidate_pairs,
        "positive_hull_pairs": positive_pairs,
    }


def decode_mesh(data) -> tuple[Face, ...]:
    positions = tuple(tuple(float_bits(component) for component in vertex)
                      for vertex in data["positions_bits"])
    if any(len(vertex) != 3 for vertex in positions):
        raise ValueError("Position entries must have three binary32 components")
    if "triangles" in data:
        triangles = data["triangles"]
    else:
        indices = data["indices"]
        if len(indices) % 3:
            raise ValueError("Triangle indices must occur in triples")
        triangles = [indices[index:index + 3] for index in range(0, len(indices), 3)]
    result = []
    for triangle in triangles:
        if len(triangle) != 3 or any(not isinstance(index, int) or not 0 <= index < len(positions)
                                     for index in triangle):
            raise ValueError("Invalid triangle index")
        result.append(tuple(positions[index] for index in triangle))
    return tuple(result)


def encode_result(value):
    if isinstance(value, F):
        return {"numerator": str(value.numerator), "denominator": str(value.denominator),
                "approximate": float(value)}
    if isinstance(value, dict):
        return {key: encode_result(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [encode_result(item) for item in value]
    return value


def audit_case(case):
    started = time.perf_counter()
    try:
        source = Source(decode_mesh(case["source"]))
        hulls = tuple(Polyhedron(
            decode_mesh(hull),
            tuple(tuple(float_bits(component) for component in vertex) for vertex in hull["positions_bits"]),
        ) for hull in case["hulls"])
        result = audit(source, hulls, float_bits(case["epsilon_bits"]))
    except ValueError as failure:
        result = {"status": "ERROR", "reason": str(failure)}

    result["name"] = case["name"]
    result["seconds"] = time.perf_counter() - started
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--jobs", type=int, default=1)
    arguments = parser.parse_args()
    if arguments.jobs < 1:
        parser.error("--jobs must be positive")

    document = json.loads(arguments.input.read_text(encoding="utf-8-sig"))
    export_failures = document.get("failures", [])
    cases = document.get("cases", [document])
    if not cases and not export_failures:
        raise ValueError("The export contains no cases or recorded reconstruction failures")

    results = []
    executor = ProcessPoolExecutor(max_workers=arguments.jobs) if arguments.jobs > 1 else None
    try:
        pending = executor.map(audit_case, cases) if executor else map(audit_case, cases)
        for result in pending:
            results.append(result)
            if result["status"] == "ERROR":
                print(f"{result['name']}: ERROR {result['reason']}", flush=True)
            else:
                print(f"{result['name']}: {result['status']} hulls={result['hulls']} "
                      f"missing<={float(result['missing_upper']):.9g} "
                      f"overlap<={float(result['overlap_upper']):.9g} "
                      f"exterior<={float(result['exterior_upper']):.9g}", flush=True)
    finally:
        if executor:
            executor.shutdown()

    for failure in export_failures:
        print(f"{failure.get('name', 'unnamed')}: RECONSTRUCTION FAILURE {failure.get('cause', 'unspecified')}", flush=True)
    report = {"oracle": "independent-fraction-convex-clipping-v1", "cases": encode_result(results),
              "export_failures": export_failures}
    if arguments.output:
        arguments.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    else:
        print(json.dumps(report, indent=2))
    return 1 if export_failures or any(result["status"] in ("FAIL", "ERROR") for result in results) else 2 if any(
        result["status"] == "INCONCLUSIVE" for result in results) else 0


if __name__ == "__main__":
    raise SystemExit(main())
