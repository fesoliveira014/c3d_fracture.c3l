# Independent full collision volume oracle

Geometric bounds: **96/96 PASS** across four fixtures, twelve rotations and hull limits 128/4. Export reconstruction failures: zero. Total published hulls: 17217.

**This is prototype geometric evidence, not final collision acceptance.** The exporter reports native cooking failures in 36 nonconvex limit-4 cases, involving 6,540 hulls. The final reconstruction fix must be exported and checked again.

| Fixture | Cases | Hulls | Largest case | Max missing upper | Max overlap upper | Max exterior upper |
|---|---:|---:|---:|---:|---:|---:|
| box | 24 | 156 | 12 | 0 | 0 | 3.03076233e-08 |
| l-prism | 24 | 372 | 30 | 2.436622338e-09 | 7.625820549e-09 | 1.063268351e-07 |
| hollow-box | 24 | 6313 | 629 | 3.544951442e-06 | 6.912433989e-06 | 1.060260888e-05 |
| nested-shell | 24 | 10376 | 1147 | 4.379898985e-06 | 5.819840558e-06 | 1.119015897e-05 |

Values above are display approximations in cubic source units. The JSON report preserves exact rational numerators and denominators. Pairwise intersection sums are upper bounds on overlap multiplicity, not exact union-overlap volume.

| Fixture | Max missing / E | Max overlap / (B+E) | Max exterior / (B+E) |
|---|---:|---:|---:|
| box | 0 | 0 | 2.288411902e-05 |
| l-prism | 9.312241292e-07 | 1.744263423e-06 | 2.217544037e-05 |
| hollow-box | 2.694656758e-05 | 3.869073661e-05 | 6.687181359e-05 |
| nested-shell | 4.435707233e-05 | 3.31875262e-05 | 6.877622172e-05 |

All ratios are at most one. The exact signed-volume condition D <= B also passes. Missing volume and overlap are exactly zero for the box subset.

The 17 analytic oracle test groups include an explicit large-rational serialization regression. The first complete calculation passed every case but hit Python's decimal conversion limit while saving; that reporting issue was fixed and the unchanged geometry was rerun successfully. Four worker processes evaluated independent cases; these oracle runtimes are not library performance measurements.

## Evidence identity

- all-ae4-o3.json: SHA256 `5dc676d2bed3967d18e08d71014dd2de8c6139ebdbb584d518e25e5e9b0c4351`
- collision_oracle.py: SHA256 `028669dd5bad2bf003220898c5eb85976145aacdebbb229cf406ee8199bc4324`
- test_collision_oracle.py: SHA256 `ed3cb36815cebde049ed0929fa0b38c9e0ce59a1f2a56dbb627c38e07ff1eb04`
- oracle-all-ae4-o3.json: SHA256 `515a6592ac66ce22c4fddc05f73a787b15e8dc088b4e15ce0923b8275453d6b2`

## Independent source-vertex audit added after the geometric run

The baseline omits 28 distinct used source positions in 15 limit-4 cases:
seven hollow-box cases and eight nested-shell cases. Every limit-128 case and
all box/L-prism cases retain every raw source XYZ bit tuple. This omission
predates the new generated-point pruning and is a separate tetrahedral-output
defect. Exact missing bit patterns, original vertex indices and point counts
are in `source-vertices-baseline-ae4-o3.json`.

The geometric PASS above remains a geometric result only; source retention and
native cooking are both unaccepted. The exact script used for this geometric
run is preserved as `oracle-baseline-ae4-v1.py` with the SHA256 recorded above.
The current v2 script adds the separate raw source-bit retention gate.
