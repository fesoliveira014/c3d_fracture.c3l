# Corrected collision output: independent oracle

**96/96 PASS** for exact geometric error bounds and raw source-position retention. All 1,440 source-position occurrences across the case inventory are retained. Reconstruction failures are absent.

Total hulls: 9877 (baseline 17,217). Total point entries: 41810 (baseline 75,330).

**Scope:** the extra authored face-center/edge-point regression is outside these 96 cases and still requires tetrahedral refinement. This report does not close that acceptance gate.

| Fixture | Cases | Hulls | Points | Max missing upper | Max overlap upper | Max exterior upper |
|---|---:|---:|---:|---:|---:|---:|
| box | 24 | 156 | 672 | 0 | 0 | 3.03076233e-08 |
| l-prism | 24 | 312 | 1344 | 1.931114278e-08 | 3.953604333e-09 | 1.063268346e-07 |
| hollow-box | 24 | 3354 | 14130 | 3.229898857e-05 | 1.739277178e-06 | 6.852212946e-06 |
| nested-shell | 24 | 6055 | 25664 | 5.108273149e-05 | 2.63671725e-06 | 7.919063039e-06 |

The table uses decimal approximations; exact numerators and denominators are retained in the JSON report. Pairwise intersection sums are upper bounds on overlap multiplicity, not exact union overlap. Every reported bound meets its own independently computed allowance.

| Fixture | Max missing/E | Max overlap/(B+E) | Max exterior/(B+E) |
|---|---:|---:|---:|
| box | 0 | 0 | 2.288411902e-05 |
| l-prism | 7.164137668e-06 | 8.281322176e-07 | 2.217544033e-05 |
| hollow-box | 0.0002500120616 | 1.139002741e-05 | 4.321765774e-05 |
| nested-shell | 0.0004220232688 | 1.522235737e-05 | 4.616736429e-05 |
